#!/bin/bash

protoc --go_out=./go/ *.proto 
